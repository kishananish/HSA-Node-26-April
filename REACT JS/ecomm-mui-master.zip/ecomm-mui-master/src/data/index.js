export const products = [
    {
        id: 1,
        name: "Super Backpack",
        price: 129.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "/images/products/bag_01.png"
    },
    {
        id: 2,
        name: "New Hip",
        price: 199.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "/images/products/bag_02.png"
    },
    {
        id: 3,
        name: "Elite Series",
        price: 189.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "/images/products/bag_03.png"
    },
    {
        id: 4,
        name: "Casual",
        price: 129.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "/images/products/bag_04.png"
    },
    {
        id: 5,
        name: "Best Tote",
        price: 399.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "/images/products/bag_05.png"
    },
    {
        id: 6,
        name: "Charming Series",
        price: 689.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "/images/products/bag_06.png"
    }
]