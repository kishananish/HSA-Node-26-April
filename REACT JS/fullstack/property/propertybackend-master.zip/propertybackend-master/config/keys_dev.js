module.exports = {
  mongoURI: 'mongodb://localhost/kkkkkkkk',
  secretOrKey: 'abcdeerf',
  GOOGLE_MAP_KEY: 'AIzaSyAQXplpRW2Ny4Ulj5K6SHh0QJbOrYjoczk'
};
