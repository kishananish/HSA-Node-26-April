This is a MERN Stack Ecommerce website. I made it for Youtube tutorials. I think everyone will like it.
In this project I am using:

M = MONGODB FOR DATABASE
E = EXPRESS JS FOR CREATING SERVER 
R = REACT JS FOR FRONTEND
R = REDUX FOR CREATE STATE AND USE THAT IN COMPONENT
N = NODE JS FOR BACKEND

Some important website links:
** NODE JS
https://nodejs.org/en/
** REACT JS
https://reactjs.org/
** NODEMAILER
https://nodemailer.com/about/
** EMAIL JS
https://www.emailjs.com/

============================== CONNECTS WITH ME ========================
INSTAGRAM: https://www.instagram.com/dev_shahriar/
YOUTUBE: https://www.youtube.com/
FACEBOOK: https://www.facebook.com/shahriar.sajeeb.16


