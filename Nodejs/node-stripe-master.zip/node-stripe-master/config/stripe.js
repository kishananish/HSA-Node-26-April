module.exports = { 
    secretKey: process.env.STRIPE_SECRET_KEY,   // Secret KEY: https://dashboard.stripe.com/account/apikeys 
}