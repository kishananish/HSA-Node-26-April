# Stripe Payment Gateway Integration In Node.js
<p align="center"><img src="https://github.com/ultimateakash/node-stripe/blob/master/public/images/node-stripe.png"></p> 

1. Copy `.env.example` to `.env`
2. Update Stripe Credentials
3. Run Project Using`npm start`
