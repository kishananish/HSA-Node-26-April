const NotFound = () => {
  return (
    <div>
      <h1>The page you are looking for does not Exit!</h1>
    </div>
  );
};

export default NotFound;
